package com.microprac.myorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyOrderServiceApplication.class, args);
	}

}
