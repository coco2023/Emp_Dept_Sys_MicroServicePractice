package com.microprac.myorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
