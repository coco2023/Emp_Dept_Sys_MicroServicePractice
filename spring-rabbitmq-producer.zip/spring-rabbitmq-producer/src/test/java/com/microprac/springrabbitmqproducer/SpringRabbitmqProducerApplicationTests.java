package com.microprac.springrabbitmqproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRabbitmqProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
