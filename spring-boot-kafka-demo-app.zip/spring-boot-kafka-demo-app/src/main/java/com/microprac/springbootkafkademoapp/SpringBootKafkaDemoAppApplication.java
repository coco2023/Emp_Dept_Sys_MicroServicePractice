package com.microprac.springbootkafkademoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKafkaDemoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKafkaDemoAppApplication.class, args);
	}

}
