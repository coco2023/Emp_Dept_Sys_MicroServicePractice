package com.microprac.springbootkafkademoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
