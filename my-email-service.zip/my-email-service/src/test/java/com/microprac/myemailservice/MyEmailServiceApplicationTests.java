package com.microprac.myemailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyEmailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
