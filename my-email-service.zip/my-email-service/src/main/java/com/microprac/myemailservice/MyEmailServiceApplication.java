package com.microprac.myemailservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEmailServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEmailServiceApplication.class, args);
	}

}
