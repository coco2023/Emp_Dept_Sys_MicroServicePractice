package com.microprac.mystockservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyStockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
