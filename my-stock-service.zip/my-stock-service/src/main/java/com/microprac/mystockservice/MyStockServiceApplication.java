package com.microprac.mystockservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyStockServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyStockServiceApplication.class, args);
	}

}
