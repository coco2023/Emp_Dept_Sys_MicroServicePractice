package com.microprac.rbacauthprac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RbacAuthPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbacAuthPracApplication.class, args);
	}

}
