package com.microprac.rbacauthprac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RbacAuthPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
