package com.microprac.springsecurityservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
