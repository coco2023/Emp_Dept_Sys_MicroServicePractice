package com.microprac.springdockersample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDockerSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
