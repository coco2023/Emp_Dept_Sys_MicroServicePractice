package com.microprac.springbootkafkaconsuner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKafkaConsunerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKafkaConsunerApplication.class, args);
	}

}
