package com.microprac.springbootkafkaconsuner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaConsunerApplicationTests {

	@Test
	void contextLoads() {
	}

}
